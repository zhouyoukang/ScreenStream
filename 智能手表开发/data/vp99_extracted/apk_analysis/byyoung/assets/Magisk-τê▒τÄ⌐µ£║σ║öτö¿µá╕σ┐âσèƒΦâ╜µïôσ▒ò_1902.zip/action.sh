am start 'intent:#Intent;action=android.intent.action.MAIN;component=com.byyoung.setting/.Magisk.MagiskAssistantActivity;end'
exit 0